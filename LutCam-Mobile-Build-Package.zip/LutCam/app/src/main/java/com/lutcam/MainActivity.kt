package com.lutcam

import android.Manifest
import android.app.AlertDialog
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: LutRenderer
    private lateinit var chips: LinearLayout
    private var st: SurfaceTexture? = null
    private var granted = false
    private var front = false
    private var imageCapture: ImageCapture? = null
    private val flashModes = listOf(ImageCapture.FLASH_MODE_OFF, ImageCapture.FLASH_MODE_AUTO, ImageCapture.FLASH_MODE_ON)
    private val flashLabels = listOf("Flash\nOff", "Flash\nAuto", "Flash\nOn")
    private var flashIdx = 0
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val dir by lazy { File(filesDir, "filters").apply { mkdirs() } }
    private var current: File? = null
    private var currentLut: Lut? = null
    private var level = 100
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it; if (it) maybeStart() else toast("Camera permission is required") }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> importFilters(uris) }

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val w = resources.displayMetrics.widthPixels
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF0B0B0F.toInt()) }
        renderer = LutRenderer({ s -> ui.post { st = s; maybeStart() } }, { glView.requestRender() })
        glView = GLSurfaceView(this).apply { setEGLContextClientVersion(2); setRenderer(renderer); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY }
        root.addView(glView, FrameLayout.LayoutParams(w, w * 4 / 3, Gravity.TOP).apply { topMargin = dp(32) })

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(16)) }
        val sbRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val pct = label("100%")
        val sb = SeekBar(this).apply {
            max = 100; progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { level = p; pct.text = "$p%"; renderer.intensity = p / 100f; glView.requestRender() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        sbRow.addView(label("Intensity")); sbRow.addView(sb, LinearLayout.LayoutParams(0, -2, 1f)); sbRow.addView(pct)
        col.addView(sbRow)
        chips = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) },
            LinearLayout.LayoutParams(-1, dp(52)))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val lp = { LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(3), 0, dp(3), 0) } }
        row.addView(btn("Import\nFilter") { importLauncher.launch(arrayOf("*/*")) }, lp())
        val flash = btn(flashLabels[0]) {}
        flash.setOnClickListener { flashIdx = (flashIdx + 1) % 3; flash.text = flashLabels[flashIdx]; imageCapture?.flashMode = flashModes[flashIdx] }
        row.addView(flash, lp())
        val shutter = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(dp(4), 0xFFFFC857.toInt()) }
            setOnClickListener { shoot() }
        }
        row.addView(shutter, LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(dp(6), 0, dp(6), 0) })
        val cmp = btn("Hold:\nOriginal") {}
        cmp.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { renderer.intensity = 0f; glView.requestRender() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { renderer.intensity = level / 100f; glView.requestRender() }
            }; true
        }
        row.addView(cmp, lp())
        row.addView(btn("Flip") { front = !front; maybeStart() }, lp())
        col.addView(row, LinearLayout.LayoutParams(-1, dp(80)))
        root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        refreshChips()
        granted = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (!granted) permLauncher.launch(Manifest.permission.CAMERA)
    }

    override fun onResume() { super.onResume(); glView.onResume() }
    override fun onPause() { glView.onPause(); super.onPause() }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(6), 0, dp(6), 0) }
    private fun btn(t: String, click: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
        background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0x33FFFFFF) }
        setOnClickListener { click() }
    }
    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    // ---------- Camera ----------
    private fun maybeStart() {
        val s = st ?: return
        if (!granted) return
        val exec = ContextCompat.getMainExecutor(this)
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val p = fut.get()
            val ratio = AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            val preview = Preview.Builder().setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build()).build()
            preview.setSurfaceProvider(exec) { req ->
                s.setDefaultBufferSize(req.resolution.width, req.resolution.height)
                val surf = Surface(s)
                req.provideSurface(surf, exec) { surf.release() }
                req.setTransformationInfoListener(exec) { info -> renderer.rotation = info.rotationDegrees; renderer.mirror = front; glView.requestRender() }
            }
            val ic = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(ratio)
                    .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY).build())
                .setFlashMode(flashModes[flashIdx]).build()
            imageCapture = ic
            p.unbindAll()
            try {
                p.bindToLifecycle(this, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, preview, ic)
            } catch (e: Exception) { toast("Camera unavailable: ${e.message}") }
        }, exec)
    }

    private fun shoot() {
        val ic = imageCapture ?: return
        val f = File(cacheDir, "cap_${System.currentTimeMillis()}.jpg")
        ic.takePicture(ImageCapture.OutputFileOptions.Builder(f).build(), io, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) = save(f)
            override fun onError(e: ImageCaptureException) = toast("Capture failed: ${e.message}")
        })
    }

    private fun decode(f: File): Bitmap {
        var s = 1
        while (true) try {
            return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inMutable = true; inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888 })!!
        } catch (e: OutOfMemoryError) { s *= 2; if (s > 8) throw e }
    }

    /** Saves to Pictures/LutCam. No filter: original JPEG untouched. Filter: LUT applied at full resolution. */
    private fun save(f: File) {
        try {
            val lut = currentLut; val k = level / 100f; val filtered = lut != null && k > 0f
            val name = "LutCam_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/LutCam"); put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            val orient = ExifInterface(f.absolutePath).getAttribute(ExifInterface.TAG_ORIENTATION)
            contentResolver.openOutputStream(uri)!!.use { out ->
                if (!filtered) f.inputStream().use { it.copyTo(out) }
                else { val bmp = decode(f); LutApply.apply(bmp, lut!!, k); bmp.compress(Bitmap.CompressFormat.JPEG, 97, out); bmp.recycle() }
            }
            if (filtered && orient != null) contentResolver.openFileDescriptor(uri, "rw")?.use {
                ExifInterface(it.fileDescriptor).apply { setAttribute(ExifInterface.TAG_ORIENTATION, orient); saveAttributes() }
            }
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            f.delete(); toast("Saved to Pictures/LutCam")
        } catch (e: Throwable) { toast("Save failed: ${e.message}") }
    }

    // ---------- Filters ----------
    private fun importFilters(uris: List<android.net.Uri>) {
        io.execute {
            var ok = 0; var bad = 0
            for (u in uris) {
                val name = contentResolver.query(u, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "filter_${System.nanoTime()}"
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in LutParser.EXT) { bad++; continue }
                val dest = File(dir, name.replace('/', '_'))
                contentResolver.openInputStream(u)?.use { i -> dest.outputStream().use { i.copyTo(it) } }
                if (LutParser.parse(dest) != null) ok++ else { dest.delete(); bad++ }
            }
            toast("Imported $ok filter(s)" + if (bad > 0) ", $bad unsupported/invalid" else "")
            ui.post { refreshChips() }
        }
    }

    private fun refreshChips() {
        chips.removeAllViews()
        fun chip(t: String, sel: Boolean, f: File?): TextView = btn(t) { select(f) }.apply {
            textSize = 13f; setPadding(dp(16), dp(8), dp(16), dp(8))
            (background as GradientDrawable).setColor(if (sel) 0xFFFFC857.toInt() else 0x33FFFFFF)
            setTextColor(if (sel) Color.BLACK else Color.WHITE)
            if (f != null) setOnLongClickListener { manage(f); true }
        }
        val lp = { LinearLayout.LayoutParams(-2, dp(40)).apply { setMargins(dp(4), 0, dp(4), 0) } }
        chips.addView(chip("None", current == null, null), lp())
        (dir.listFiles() ?: emptyArray()).filter { it.extension.lowercase() in LutParser.EXT }.sortedBy { it.name.lowercase() }
            .forEach { chips.addView(chip(it.nameWithoutExtension, it == current, it), lp()) }
    }

    private fun select(f: File?) {
        current = f
        if (f == null) { currentLut = null; glView.queueEvent { renderer.setLut(null) }; glView.requestRender(); refreshChips(); return }
        io.execute {
            val l = LutParser.parse(f)
            if (l == null) { toast("Could not read ${f.name}"); return@execute }
            currentLut = l
            glView.queueEvent { renderer.setLut(l) }; glView.requestRender()
            ui.post { refreshChips() }
        }
    }

    private fun manage(f: File) {
        AlertDialog.Builder(this).setTitle(f.nameWithoutExtension).setItems(arrayOf("Rename", "Delete")) { _, i ->
            if (i == 1) { f.delete(); if (current == f) select(null) else refreshChips() }
            else {
                val et = EditText(this).apply { setText(f.nameWithoutExtension) }
                AlertDialog.Builder(this).setTitle("Rename").setView(et).setPositiveButton("OK") { _, _ ->
                    val n = et.text.toString().trim().replace('/', '_')
                    if (n.isNotEmpty()) { val nf = File(dir, n + "." + f.extension); if (f.renameTo(nf) && current == f) current = nf; refreshChips() }
                }.setNegativeButton("Cancel", null).show()
            }
        }.show()
    }
}
