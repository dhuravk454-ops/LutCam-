package com.lutcam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** 3D LUT. data = RGB floats 0..1, red varies fastest: index = ((b*n + g)*n + r)*3 */
class Lut(val size: Int, val data: FloatArray) {
    /** 2D strip for GL: width n*n, height n, pixel (b*n + r, g). */
    fun toStrip(): ByteBuffer {
        val n = size
        val buf = ByteBuffer.allocateDirect(n * n * n * 3)
        for (g in 0 until n) for (b in 0 until n) for (r in 0 until n) {
            val s = ((b * n + g) * n + r) * 3
            for (c in 0..2) buf.put((data[s + c].coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte())
        }
        buf.rewind(); return buf
    }
}

object LutParser {
    val EXT = setOf("cube", "3dl", "png", "jpg", "jpeg")

    fun parse(f: File): Lut? = try {
        when (f.extension.lowercase()) {
            "cube" -> cube(f)
            "3dl" -> threeDl(f)
            "png", "jpg", "jpeg" -> image(f)
            else -> null
        }
    } catch (e: Exception) { null }

    private val ws = Regex("\\s+")
    private fun isNum(s: String) = s.isNotEmpty() && (s[0].isDigit() || s[0] == '-' || s[0] == '.')

    private fun cube(f: File): Lut? {
        var n = 0; var d = FloatArray(0); var i = 0
        f.forEachLine { raw ->
            val l = raw.trim()
            if (l.isEmpty() || l[0] == '#') return@forEachLine
            if (l.startsWith("LUT_3D_SIZE")) { n = l.split(ws)[1].toInt(); d = FloatArray(n * n * n * 3); return@forEachLine }
            val p = l.split(ws)
            if (p.size == 3 && isNum(p[0]) && i + 3 <= d.size) { d[i++] = p[0].toFloat(); d[i++] = p[1].toFloat(); d[i++] = p[2].toFloat() }
        }
        return if (n > 1 && i == d.size) Lut(n, d) else null
    }

    private fun threeDl(f: File): Lut? {
        val v = ArrayList<FloatArray>()
        f.forEachLine { raw ->
            val p = raw.trim().split(ws)
            if (p.size == 3 && isNum(p[0])) v.add(floatArrayOf(p[0].toFloat(), p[1].toFloat(), p[2].toFloat()))
        }
        val n = Math.cbrt(v.size.toDouble()).roundToInt()
        if (n < 2 || n * n * n != v.size) return null
        var mx = 0f; for (t in v) for (c in t) mx = max(mx, c)
        val norm = if (mx <= 1.5f) 1f else if (mx <= 1023f) 1023f else if (mx <= 4095f) 4095f else 65535f
        val d = FloatArray(v.size * 3)
        for (r in 0 until n) for (g in 0 until n) for (b in 0 until n) { // file order: blue fastest
            val t = v[(r * n + g) * n + b]; val o = ((b * n + g) * n + r) * 3
            d[o] = t[0] / norm; d[o + 1] = t[1] / norm; d[o + 2] = t[2] / norm
        }
        return Lut(n, d)
    }

    /** Supports strip LUTs (width = height^2) and Hald CLUTs (square, side = level^3). */
    private fun image(f: File): Lut? {
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inScaled = false }) ?: return null
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h); bmp.recycle()
        val n: Int
        val d: FloatArray
        fun put(d: FloatArray, o: Int, c: Int) { d[o] = (c shr 16 and 255) / 255f; d[o + 1] = (c shr 8 and 255) / 255f; d[o + 2] = (c and 255) / 255f }
        if (w == h * h) {
            n = h; d = FloatArray(n * n * n * 3)
            for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) put(d, ((b * n + g) * n + r) * 3, px[g * w + b * n + r])
        } else if (w == h) {
            val lv = Math.cbrt(w.toDouble()).roundToInt()
            if (lv * lv * lv != w) return null
            n = lv * lv; d = FloatArray(n * n * n * 3)
            for (k in 0 until n * n * n) put(d, k * 3, px[k])
        } else return null
        return Lut(n, d)
    }
}

object LutApply {
    /** Applies the LUT in place, in row bands so 48MP photos fit in memory. */
    fun apply(bmp: Bitmap, lut: Lut, k: Float) {
        val w = bmp.width; val h = bmp.height; val n = lut.size; val m = (n - 1).toFloat(); val d = lut.data
        val band = 128; val px = IntArray(w * band)
        var y = 0
        while (y < h) {
            val rows = min(band, h - y)
            bmp.getPixels(px, 0, w, 0, y, w, rows)
            for (i in 0 until w * rows) {
                val c = px[i]
                val r = (c shr 16 and 255) / 255f; val g = (c shr 8 and 255) / 255f; val b = (c and 255) / 255f
                val rf = r * m; val gf = g * m; val bf = b * m
                val r0 = rf.toInt(); val g0 = gf.toInt(); val b0 = bf.toInt()
                val fr = rf - r0; val fg = gf - g0; val fb = bf - b0
                val r1 = min(r0 + 1, n - 1); val g1 = min(g0 + 1, n - 1); val b1 = min(b0 + 1, n - 1)
                var o0 = 0f; var o1 = 0f; var o2 = 0f
                for (z in 0..1) for (yy in 0..1) for (x in 0..1) {
                    val wgt = (if (x == 1) fr else 1 - fr) * (if (yy == 1) fg else 1 - fg) * (if (z == 1) fb else 1 - fb)
                    val s = (((if (z == 1) b1 else b0) * n + (if (yy == 1) g1 else g0)) * n + (if (x == 1) r1 else r0)) * 3
                    o0 += d[s] * wgt; o1 += d[s + 1] * wgt; o2 += d[s + 2] * wgt
                }
                val orr = (r + (o0 - r) * k).coerceIn(0f, 1f); val og = (g + (o1 - g) * k).coerceIn(0f, 1f); val ob = (b + (o2 - b) * k).coerceIn(0f, 1f)
                px[i] = (0xFF shl 24) or ((orr * 255f + .5f).toInt() shl 16) or ((og * 255f + .5f).toInt() shl 8) or (ob * 255f + .5f).toInt()
            }
            bmp.setPixels(px, 0, w, 0, y, w, rows)
            y += rows
        }
    }
}
