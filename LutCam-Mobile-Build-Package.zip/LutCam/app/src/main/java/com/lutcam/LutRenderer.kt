package com.lutcam

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Draws the camera frames through a 3D LUT fragment shader (GPU, real time). */
class LutRenderer(private val onReady: (SurfaceTexture) -> Unit, private val onFrame: () -> Unit) : GLSurfaceView.Renderer {
    @Volatile var intensity = 1f
    @Volatile var rotation = 0
    @Volatile var mirror = false
    private var st: SurfaceTexture? = null
    private var prog = 0; private var camTex = 0; private var lutTex = 0; private var lutSize = 0
    private val stm = FloatArray(16); private val m = FloatArray(16); private val mat = FloatArray(16)
    private val vb = fb(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val tb = fb(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))
    private fun fb(a: FloatArray) = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(a); position(0) }

    private val vs = "attribute vec4 aPos; attribute vec2 aTex; uniform mat4 uMat; varying vec2 vTex;" +
        "void main(){ gl_Position=aPos; vTex=(uMat*vec4(aTex,0.0,1.0)).xy; }"
    private val fs = "#extension GL_OES_EGL_image_external : require\nprecision highp float;" +
        "varying vec2 vTex; uniform samplerExternalOES uCam; uniform sampler2D uLut; uniform float uSize; uniform float uInt;" +
        "vec3 look(vec3 c){ float m=uSize-1.0; float bf=c.b*m; float b0=floor(bf); float b1=min(b0+1.0,m); float f=bf-b0;" +
        " float v=(c.g*m+0.5)/uSize; float w=uSize*uSize;" +
        " return mix(texture2D(uLut,vec2((b0*uSize+c.r*m+0.5)/w,v)).rgb, texture2D(uLut,vec2((b1*uSize+c.r*m+0.5)/w,v)).rgb, f); }" +
        "void main(){ vec3 c=clamp(texture2D(uCam,vTex).rgb,0.0,1.0); gl_FragColor=vec4(mix(c,look(c),uInt),1.0); }"

    private fun sh(type: Int, src: String) = GLES20.glCreateShader(type).also { GLES20.glShaderSource(it, src); GLES20.glCompileShader(it) }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, sh(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(prog, sh(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(prog)
        val t = IntArray(2); GLES20.glGenTextures(2, t, 0); camTex = t[0]; lutTex = t[1]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
        for ((k, v) in listOf(GLES20.GL_TEXTURE_MIN_FILTER to GLES20.GL_LINEAR, GLES20.GL_TEXTURE_MAG_FILTER to GLES20.GL_LINEAR,
            GLES20.GL_TEXTURE_WRAP_S to GLES20.GL_CLAMP_TO_EDGE, GLES20.GL_TEXTURE_WRAP_T to GLES20.GL_CLAMP_TO_EDGE))
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, k, v)
        lutSize = 0; setLut(null)
        st = SurfaceTexture(camTex).also { it.setOnFrameAvailableListener { onFrame() }; onReady(it) }
    }

    /** Must run on the GL thread (use GLSurfaceView.queueEvent). */
    fun setLut(l: Lut?) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lutTex)
        for ((k, v) in listOf(GLES20.GL_TEXTURE_MIN_FILTER to GLES20.GL_LINEAR, GLES20.GL_TEXTURE_MAG_FILTER to GLES20.GL_LINEAR,
            GLES20.GL_TEXTURE_WRAP_S to GLES20.GL_CLAMP_TO_EDGE, GLES20.GL_TEXTURE_WRAP_T to GLES20.GL_CLAMP_TO_EDGE))
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, k, v)
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
        if (l == null) {
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGB, 1, 1, 0, GLES20.GL_RGB, GLES20.GL_UNSIGNED_BYTE, ByteBuffer.allocateDirect(3))
            lutSize = 0
        } else {
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGB, l.size * l.size, l.size, 0, GLES20.GL_RGB, GLES20.GL_UNSIGNED_BYTE, l.toStrip())
            lutSize = l.size
        }
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) = GLES20.glViewport(0, 0, w, h)

    override fun onDrawFrame(gl: GL10?) {
        val s = st ?: return
        s.updateTexImage(); s.getTransformMatrix(stm)
        Matrix.setIdentityM(m, 0)
        Matrix.translateM(m, 0, .5f, .5f, 0f)
        Matrix.rotateM(m, 0, rotation.toFloat(), 0f, 0f, 1f)
        if (mirror) Matrix.scaleM(m, 0, -1f, 1f, 1f)
        Matrix.translateM(m, 0, -.5f, -.5f, 0f)
        Matrix.multiplyMM(mat, 0, stm, 0, m, 0)
        GLES20.glClearColor(0f, 0f, 0f, 1f); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lutTex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uCam"), 0)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uLut"), 1)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uSize"), maxOf(lutSize, 1).toFloat())
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uInt"), if (lutSize > 1) intensity else 0f)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMat"), 1, false, mat, 0)
        val ap = GLES20.glGetAttribLocation(prog, "aPos"); val at = GLES20.glGetAttribLocation(prog, "aTex")
        GLES20.glEnableVertexAttribArray(ap); GLES20.glVertexAttribPointer(ap, 2, GLES20.GL_FLOAT, false, 8, vb)
        GLES20.glEnableVertexAttribArray(at); GLES20.glVertexAttribPointer(at, 2, GLES20.GL_FLOAT, false, 8, tb)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }
}
