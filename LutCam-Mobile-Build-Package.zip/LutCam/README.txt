LutCam (Phase 1) - Android Studio project
1. Android Studio (Hedgehog or newer): File > Open > select this LutCam folder, let Gradle sync.
2. Plug in a phone (Android 10+), press Run. Or Build > Build APK(s) for an installable APK.
Filters: tap "Import Filter", pick .cube / .3dl / strip .png/.jpg (width = height^2) / Hald CLUT .png.
Long-press a filter chip to rename or delete. Slider = intensity. Hold "Original" to compare.
If the preview appears rotated/flipped on your phone, tell me the device and I will fix the transform.
